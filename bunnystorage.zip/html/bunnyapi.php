<?php
require 'vendor/autoload.php';

use ToshY\BunnyNet\BaseAPI;
use ToshY\BunnyNet\Client\BunnyClient;

$bunnyClient = new BunnyClient(
    client: new \Symfony\Component\HttpClient\Psr18Client(),
);

// Provide the account API key.
$baseApi = new BaseAPI(
    apiKey: '3d51be6d-405f-43a3-a72c-d1b20878ddfbe08be38a-950b-4650-a89a-4f7eb20468a7',
    client: $bunnyClient,
);
//print_r($baseApi);

$list=$baseApi->listCountries();
print_r($list);
