<?php

require 'vendor/autoload.php';

use ToshY\BunnyNet\Client\BunnyClient;
use ToshY\BunnyNet\EdgeStorageAPI;
use ToshY\BunnyNet\Enum\Region;

$bunnyClient = new BunnyClient(
    client: new \Symfony\Component\HttpClient\Psr18Client(),
);

// Provide the password of the specific storage zone.
$edgeStorageApi = new EdgeStorageAPI(
    apiKey: '7aaec012-ea75-408f-ae7ca8a3c181-557c-4edc',
    client: $bunnyClient,
    region: Region::DE,
);

/*$name=$edgeStorageApi->downloadFile(
    storageZoneName: 'mystoragephpasset',
    fileName: 'monit.txt',
);
//print_r($name);
$list=$edgeStorageApi->listFiles(
    storageZoneName: 'mystoragephpasset',
);
print_r($list);
*/

$storageZoneName = 'mystoragephpasset';
try {
    // Fetch the list of files
    $response = $edgeStorageApi->listFiles(storageZoneName: $storageZoneName);

    // Access the contents using the getter
    $files = $response->getContents();

    // Loop through the files and get their names
    foreach ($files as $file) {
        echo "File Name: " . $file['ObjectName'] . "\n";
    }
} catch (\ToshY\BunnyNet\Exception\BunnyClientResponseException $e) {
    echo "Error: " . $e->getMessage();
} catch (\Exception $e) {
    echo "Unexpected Error: " . $e->getMessage();
}
