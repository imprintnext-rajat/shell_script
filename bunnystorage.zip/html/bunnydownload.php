<?php

require 'vendor/autoload.php';

use ToshY\BunnyNet\Client\BunnyClient;
use ToshY\BunnyNet\EdgeStorageAPI;
use ToshY\BunnyNet\Enum\Region;

// Initialize BunnyClient
$bunnyClient = new BunnyClient(
    client: new \Symfony\Component\HttpClient\Psr18Client(),
);

// Initialize EdgeStorageAPI
$edgeStorageApi = new EdgeStorageAPI(
    apiKey: '7aaec012-ea75-408f-ae7ca8a3c181-557c-4edc',
    client: $bunnyClient,
    region: Region::DE,
);

$storageZoneName = 'mystoragephpasset';
$remoteFileName = 'monit.txt'; // File name in BunnyNet storage
$localFileName = 'monit_local.txt'; // File name for the local copy

try {
    $fileContent = $edgeStorageApi->downloadFile(
        storageZoneName: $storageZoneName,
        fileName: $remoteFileName
    );

    if (!$fileContent) {
        throw new Exception("File content is empty or could not be retrieved.");
    }

    // Save the content to a local file
    file_put_contents($localFileName, $fileContent);

    echo "File downloaded successfully and saved as $localFileName";
} catch (\ToshY\BunnyNet\Exception\BunnyClientResponseException $e) {
    echo "BunnyNet Error: " . $e->getMessage();
} catch (\Exception $e) {
    echo "Unexpected Error: " . $e->getMessage();
}
