<?php

require 'vendor/autoload.php';

use ToshY\BunnyNet\Client\BunnyClient;
use ToshY\BunnyNet\EdgeStorageAPI;
use ToshY\BunnyNet\Enum\Region;

// Initialize BunnyClient
$bunnyClient = new BunnyClient(
    client: new \Symfony\Component\HttpClient\Psr18Client(),
);

// Initialize EdgeStorageAPI
$edgeStorageApi = new EdgeStorageAPI(
    apiKey: '7aaec012-ea75-408f-ae7ca8a3c181-557c-4edc',
    client: $bunnyClient,
    region: Region::DE,
);

// Local file to upload
$localFilePath = './index.html';
$remoteFileName = 'index.html'; // Name in BunnyNet storage

try {
    // Check if the local file exists
    if (!file_exists($localFilePath)) {
        throw new Exception("Local file does not exist: $localFilePath");
    }

    // Read the file content
    $content = file_get_contents($localFilePath);
    if ($content === false) {
        throw new Exception("Failed to read the local file: $localFilePath");
    }

    // Upload the file content to BunnyNet
    $edgeStorageApi->uploadFile(
        storageZoneName: 'mystoragephpasset',
        fileName: $remoteFileName,
        body: $content
    );

    echo "File uploaded successfully to BunnyNet as $remoteFileName.";
} catch (\ToshY\BunnyNet\Exception\BunnyClientResponseException $e) {
    echo "BunnyNet Error: " . $e->getMessage();
} catch (Exception $e) {
    echo "Unexpected Error: " . $e->getMessage();
}
